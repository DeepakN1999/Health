import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placeappointment',
  templateUrl: './placeappointment.component.html',
  styleUrls: ['./placeappointment.component.css']
})
export class PlaceappointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
