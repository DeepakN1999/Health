import { HeaderComponent } from './header/header.component';
import { ContactusComponent } from './contactus/contactus.component';
import { PlaceappointmentComponent } from './placeappointment/placeappointment.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path:"viewappointment", component:ViewappointmentComponent
  },
  {
    path:"placeappointment", component:PlaceappointmentComponent
  },
  {
    path:"contactus", component:ContactusComponent
  },
  {
    path:"header" ,component:HeaderComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
